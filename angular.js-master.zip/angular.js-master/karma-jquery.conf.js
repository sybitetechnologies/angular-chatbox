'use strict';

var karmaConfigFactory = require('./karma-jquery.conf-factory');

module.exports = karmaConfigFactory();
