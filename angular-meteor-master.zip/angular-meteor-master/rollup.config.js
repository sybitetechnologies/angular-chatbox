export default {
  format: 'umd',
  globals: {
    '@angular/core':'ng.core',
    'angular2-meteor-polyfills':'ng.meteor.polyfills',
    'underscore': 'underscore'
  }
};
