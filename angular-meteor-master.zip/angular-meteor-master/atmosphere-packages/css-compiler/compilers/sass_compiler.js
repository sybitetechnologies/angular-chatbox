
SassCompilerExtended = class SassCompilerExtended extends SassCompiler {

};

classMixin(SassCompilerExtended, BasicCompiler);
