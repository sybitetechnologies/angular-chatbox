## Todo demo app

A demo app for `angular2-meteor` NPM.

In order to run:

```
npm install
meteor

```