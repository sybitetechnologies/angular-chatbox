package it.moondroid.chatbot;

/**
 * Created by marco.granatiero on 30/09/2014.
 */
public class ChatMessage {
    public boolean left;
    public String text;

    public ChatMessage(boolean left, String text) {
        super();
        this.left = left;
        this.text = text;
    }

}
