ChatBot
=============
### Description
Android chat experiment with an A.L.I.C.E. artificial intelligence.
[A.L.I.C.E.](http://www.alicebot.org/about.html) (Artificial Linguistic Internet Computer Entity) is an award-winning free natural language artificial intelligence chat robot engine.

### Screenshots
![Demo](art/device-2015-03-30-105630.png)

![Demo](art/device-2015-03-30-105702.png)

![Demo](art/device-2015-03-30-105802.png)